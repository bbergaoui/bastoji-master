<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>QObject</name>
    <message>
        <location filename="myi18nobject.cpp" line="49"/>
        <source>Hello, world!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
