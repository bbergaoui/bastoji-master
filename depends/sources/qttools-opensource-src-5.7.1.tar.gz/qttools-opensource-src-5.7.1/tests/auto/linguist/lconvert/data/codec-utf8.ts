<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>FooBar</name>
    <message>
        <location filename="main.cpp" line="10"/>
        <source>random ascii only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="11"/>
        <source>this contains an umlaut ü &amp;uuml;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="12"/>
        <source>random ascii only in utf8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="13"/>
        <source>umlaut ü &amp;uuml; in utf8</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
