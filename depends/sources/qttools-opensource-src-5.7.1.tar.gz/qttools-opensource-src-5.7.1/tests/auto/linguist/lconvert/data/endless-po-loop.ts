<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>Assistant</name>
    <message>
        <source>This is some text which introduces the DonauDampfSchifffahrtsKapitaensMuetzeMitKomischenUltraViolettenFransenUndEinemKnopf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="this/is/a/really/really/absurdly/no,/grotesquely/long/path/supposed/to/blow/up.cpp" line="20"/>
        <source>%n document(s) found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
