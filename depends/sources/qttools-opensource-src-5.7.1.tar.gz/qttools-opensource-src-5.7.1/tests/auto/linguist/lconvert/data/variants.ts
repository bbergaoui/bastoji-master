<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>Assistant</name>
    <message>
        <source>Source</source>
        <translation variants="yes">
            <lengthvariant>A really very long translation</lengthvariant>
            <lengthvariant>Short translation</lengthvariant>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n document(s) found.</source>
        <translation>
            <numerusform>1 Dokument gefunden.</numerusform>
            <numerusform variants="yes">
                <lengthvariant>%n Dokumente gefunden.</lengthvariant>
                <lengthvariant>%n Dok. gefunden.</lengthvariant>
            </numerusform>
        </translation>
    </message>
</context>
</TS>
