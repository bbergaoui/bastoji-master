<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Foo</name>
    <message>
        <location filename="foo.cpp" line="+13"/>
        <source>This is the first entry.</source>
        <translation></translation>
    </message>
    <message>
        <location line="+0"/>
        <source>And a second one on the same line.</source>
        <translation></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>This tr is new.</source>
        <translation></translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+16"/>
        <source>This one moved in from another file.</source>
        <translation></translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Just as this one.</source>
        <translation></translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="bar.cpp" line="+100"/>
        <source>Another alien.</source>
        <translation></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>They are coming!</source>
        <translation></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>They are everywhere!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bar.cpp" line="+20"/>
        <source>An earthling again.</source>
        <translation></translation>
    </message>
    <message>
        <location line="-5"/>
        <source>This is from the bottom, too.</source>
        <translation></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Third string from the bottom.</source>
        <translation></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Fourth one!</source>
        <translation></translation>
    </message>
    <message>
        <location line="-9"/>
        <source>This string did move from the bottom.</source>
        <translation></translation>
    </message>
</context>
</TS>
