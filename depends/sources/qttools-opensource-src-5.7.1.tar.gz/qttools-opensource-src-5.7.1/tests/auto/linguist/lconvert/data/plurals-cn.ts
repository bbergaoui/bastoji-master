<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cn">
<context>
    <name>Assistant</name>
    <message>
        <source>Source</source>
        <translation>Translation</translation>
    </message>
    <message numerus="yes">
        <source>%n document(s) found.</source>
        <translation>
            <numerusform>1 Dokument gefunden.</numerusform>
        </translation>
    </message>
</context>
</TS>
